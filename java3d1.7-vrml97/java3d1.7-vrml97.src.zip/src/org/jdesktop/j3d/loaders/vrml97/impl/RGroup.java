package org.jdesktop.j3d.loaders.vrml97.impl;

import org.jogamp.java3d.BranchGroup;

public class RGroup extends BranchGroup
{
  public RGroup()
  {
    setCapability(12);
    setCapability(13);
    setCapability(14);
    setCapability(17);
    setCapability(3);
    setCapability(4);
    setCapability(9);
    setCapability(10);
    setCapability(11);
  }
}

/* Location:           C:\temp\j3d-vrml97.jar
 * Qualified Name:     org.jdesktop.j3d.loaders.vrml97.impl.RGroup
 * JD-Core Version:    0.6.0
 */