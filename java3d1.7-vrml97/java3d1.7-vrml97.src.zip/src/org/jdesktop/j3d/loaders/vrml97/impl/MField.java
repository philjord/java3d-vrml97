package org.jdesktop.j3d.loaders.vrml97.impl;

public abstract class MField extends Field
{
  public abstract int getSize();

  public abstract void clear();

  public abstract void delete(int paramInt);
}

/* Location:           C:\temp\j3d-vrml97.jar
 * Qualified Name:     org.jdesktop.j3d.loaders.vrml97.impl.MField
 * JD-Core Version:    0.6.0
 */