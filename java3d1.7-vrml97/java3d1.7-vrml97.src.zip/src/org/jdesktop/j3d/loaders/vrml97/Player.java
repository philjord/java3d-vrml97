package org.jdesktop.j3d.loaders.vrml97;

public abstract interface Player
{
  public abstract void setGotoString(String paramString);
}

/* Location:           C:\temp\j3d-vrml97.jar
 * Qualified Name:     org.jdesktop.j3d.loaders.vrml97.Player
 * JD-Core Version:    0.6.0
 */