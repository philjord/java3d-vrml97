package org.jdesktop.j3d.loaders.vrml97.impl;

public abstract interface Notifier
{
  public abstract void notifyMethod(String paramString, double paramDouble);
}

/* Location:           C:\temp\j3d-vrml97.jar
 * Qualified Name:     org.jdesktop.j3d.loaders.vrml97.impl.Notifier
 * JD-Core Version:    0.6.0
 */