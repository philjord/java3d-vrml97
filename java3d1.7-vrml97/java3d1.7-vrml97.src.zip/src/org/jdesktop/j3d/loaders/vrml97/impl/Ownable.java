package org.jdesktop.j3d.loaders.vrml97.impl;

abstract interface Ownable
{
  public abstract boolean getSolid();

  public abstract void setOwner(Shape paramShape);
}

/* Location:           C:\temp\j3d-vrml97.jar
 * Qualified Name:     org.jdesktop.j3d.loaders.vrml97.impl.Ownable
 * JD-Core Version:    0.6.0
 */