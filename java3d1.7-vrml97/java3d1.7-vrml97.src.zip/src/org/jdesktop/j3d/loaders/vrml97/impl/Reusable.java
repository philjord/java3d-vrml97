package org.jdesktop.j3d.loaders.vrml97.impl;

abstract interface Reusable
{
  public abstract void reset();
}

/* Location:           C:\temp\j3d-vrml97.jar
 * Qualified Name:     org.jdesktop.j3d.loaders.vrml97.impl.Reusable
 * JD-Core Version:    0.6.0
 */