package org.jdesktop.j3d.loaders.vrml97.impl;

public abstract interface Namespace
{
  public abstract void define(String paramString, BaseNode paramBaseNode);

  public abstract BaseNode use(String paramString);
}

/* Location:           C:\temp\j3d-vrml97.jar
 * Qualified Name:     org.jdesktop.j3d.loaders.vrml97.impl.Namespace
 * JD-Core Version:    0.6.0
 */