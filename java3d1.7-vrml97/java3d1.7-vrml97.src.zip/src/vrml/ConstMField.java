package vrml;

public abstract class ConstMField extends ConstField
{
  public abstract int getSize();
}

/* Location:           C:\temp\j3d-vrml97.jar
 * Qualified Name:     vrml.ConstMField
 * JD-Core Version:    0.6.0
 */