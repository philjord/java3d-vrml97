package vrml;

public class InvalidEventOutException extends IllegalArgumentException
{
  public InvalidEventOutException()
  {
  }

  public InvalidEventOutException(String s)
  {
    super(s);
  }
}

/* Location:           C:\temp\j3d-vrml97.jar
 * Qualified Name:     vrml.InvalidEventOutException
 * JD-Core Version:    0.6.0
 */