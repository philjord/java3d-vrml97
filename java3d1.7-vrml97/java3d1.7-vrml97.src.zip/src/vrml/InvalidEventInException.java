package vrml;

public class InvalidEventInException extends IllegalArgumentException
{
  public InvalidEventInException()
  {
  }

  public InvalidEventInException(String s)
  {
    super(s);
  }
}

/* Location:           C:\temp\j3d-vrml97.jar
 * Qualified Name:     vrml.InvalidEventInException
 * JD-Core Version:    0.6.0
 */