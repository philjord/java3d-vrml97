package vrml;

public class InvalidNavigationTypeException extends IllegalArgumentException
{
}

/* Location:           C:\temp\j3d-vrml97.jar
 * Qualified Name:     vrml.InvalidNavigationTypeException
 * JD-Core Version:    0.6.0
 */