package vrml;

public class InvalidRouteException extends IllegalArgumentException
{
}

/* Location:           C:\temp\j3d-vrml97.jar
 * Qualified Name:     vrml.InvalidRouteException
 * JD-Core Version:    0.6.0
 */