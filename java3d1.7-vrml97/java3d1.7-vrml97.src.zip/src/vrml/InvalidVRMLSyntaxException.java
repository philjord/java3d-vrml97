package vrml;

public class InvalidVRMLSyntaxException extends IllegalArgumentException
{
  public InvalidVRMLSyntaxException()
  {
  }

  public InvalidVRMLSyntaxException(String s)
  {
    super(s);
  }
}

/* Location:           C:\temp\j3d-vrml97.jar
 * Qualified Name:     vrml.InvalidVRMLSyntaxException
 * JD-Core Version:    0.6.0
 */