package vrml;

public class InvalidFieldException extends IllegalArgumentException
{
  public InvalidFieldException()
  {
  }

  public InvalidFieldException(String s)
  {
    super(s);
  }
}

/* Location:           C:\temp\j3d-vrml97.jar
 * Qualified Name:     vrml.InvalidFieldException
 * JD-Core Version:    0.6.0
 */