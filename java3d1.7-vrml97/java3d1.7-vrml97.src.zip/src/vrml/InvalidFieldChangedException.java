package vrml;

public class InvalidFieldChangedException extends IllegalArgumentException
{
  public InvalidFieldChangedException()
  {
  }

  public InvalidFieldChangedException(String s)
  {
    super(s);
  }
}

/* Location:           C:\temp\j3d-vrml97.jar
 * Qualified Name:     vrml.InvalidFieldChangedException
 * JD-Core Version:    0.6.0
 */