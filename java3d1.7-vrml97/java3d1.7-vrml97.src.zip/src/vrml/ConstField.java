package vrml;

public abstract class ConstField extends Field
{
  public ConstField()
  {
    super(null);
  }

  public void markWritable()
  {
  }
}

/* Location:           C:\temp\j3d-vrml97.jar
 * Qualified Name:     vrml.ConstField
 * JD-Core Version:    0.6.0
 */